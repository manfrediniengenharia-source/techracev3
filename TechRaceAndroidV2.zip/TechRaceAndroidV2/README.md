# TechRace Android V2

Versão 0.2.0 do cliente Android para o módulo TechRace Flex.

## Novidades V2
- Dashboard escuro inspirado no mockup aprovado.
- Conta-giros grande com mínimo/máximo.
- Cards MAP, Lambda, Injeção, Correção, Temperatura e Etanol.
- Gráficos em tempo real para RPM, MAP, Lambda e tempo de injeção.
- Indicadores Sonda/RPM, MAP e Comunicação.
- Menu inferior: Monitor, Ajustes, Programação, Diagnóstico e Configuração.
- USB OTG 19200 8N1 preservado.
- Leitura contínua automática após conexão.
- Programar Sonda/RPM e Programar MAP continuam protegidos por confirmação.
- Tela de diagnóstico mostra o RX hexadecimal bruto.

## Observação técnica
A curva real de temperatura NTC ainda não foi validada. Por segurança, a V2 mostra `--` no card de temperatura e não usa temperatura para nenhuma decisão de controle. O restante da telemetria usa o decoder da V1.

## Build
O projeto está configurado para Java/Kotlin 17, compileSdk/targetSdk 34 e pode ser compilado no mesmo GitHub Actions da V1 com `gradle assembleDebug`.
