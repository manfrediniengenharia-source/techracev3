package br.com.anderson.techrace

import java.util.Locale

object TechRaceProtocol {
    const val BAUD_RATE = 19200

    // Quadros confirmados na análise anterior do software Windows.
    val READ_LIVE_10: ByteArray = byteArrayOf(
        0xF3.toByte(), 0x00, 0x00, 0x43, 0x0A, 0xFD.toByte()
    )

    val PROGRAM_SONDA_RPM: ByteArray = byteArrayOf(
        0xF3.toByte(), 0x01, 0x00, 0x0D, 0x01, 0x01, 0xA5.toByte()
    )

    val PROGRAM_MAP: ByteArray = byteArrayOf(
        0xF3.toByte(), 0x01, 0x00, 0x0D, 0x01, 0x02, 0xAC.toByte()
    )

    fun crc8(data: ByteArray): Byte {
        var crc = 0
        for (value in data) {
            crc = crc xor (value.toInt() and 0xFF)
            repeat(8) {
                crc = if ((crc and 0x80) != 0) {
                    ((crc shl 1) xor 0x07) and 0xFF
                } else {
                    (crc shl 1) and 0xFF
                }
            }
        }
        return crc.toByte()
    }

    fun toHex(data: ByteArray): String = data.joinToString(" ") {
        String.format(Locale.US, "%02X", it.toInt() and 0xFF)
    }

    /**
     * Extrator propositalmente tolerante para a V1.
     * Se a resposta tiver cabeçalho F3 + OP + ADDR_H + ADDR_L + LEN, usa LEN bytes após o byte 4.
     * Se ainda não conhecermos o enquadramento da resposta, aceita exatamente 10 bytes como payload bruto.
     */
    fun extractLivePayload(response: ByteArray): ByteArray? {
        if (response.size >= 15 && (response[0].toInt() and 0xFF) == 0xF3) {
            val len = response[4].toInt() and 0xFF
            if (len >= 10 && response.size >= 5 + len) {
                return response.copyOfRange(5, 15)
            }
        }
        if (response.size == 10) return response.copyOf()
        if (response.size > 10) return response.copyOfRange(response.size - 10, response.size)
        return null
    }
}
