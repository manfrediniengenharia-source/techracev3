package br.com.anderson.techrace

import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.*
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val actionUsbPermission = "br.com.anderson.techrace.USB_PERMISSION"
    private lateinit var usbManager: UsbManager
    private var port: UsbSerialPort? = null
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var polling = false
    private var lastRx = byteArrayOf()
    private var pollingIntervalMs = 250L
    private var rpmCalibration = 1.0
    private lateinit var dashboard: DashboardView

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != actionUsbPermission) return
            val device = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
            } else {
                @Suppress("DEPRECATION") intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
            }
            if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && device != null) {
                openDevice(device)
            } else {
                toast("Permissão USB negada")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(6, 9, 11)
        window.navigationBarColor = Color.rgb(6, 9, 11)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        val filter = IntentFilter(actionUsbPermission)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(usbReceiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(usbReceiver, filter)

        dashboard = DashboardView(this).apply {
            onUsbClick = { findAndConnect() }
            onNavClick = { handleNav(it) }
        }
        setContentView(dashboard)
    }

    override fun onDestroy() {
        polling = false
        try { port?.close() } catch (_: Exception) {}
        ioExecutor.shutdownNow()
        try { unregisterReceiver(usbReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun handleNav(nav: DashboardView.Nav) {
        when (nav) {
            DashboardView.Nav.MONITOR -> Unit
            DashboardView.Nav.AJUSTES -> showAdjustments()
            DashboardView.Nav.PROGRAMACAO -> showProgramming()
            DashboardView.Nav.DIAGNOSTICO -> showDiagnostics()
            DashboardView.Nav.CONFIG -> showConfig()
        }
    }

    private fun showAdjustments() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(42, 18, 42, 8)
        }
        val rpm = EditText(this).apply {
            hint = "Calibração RPM"
            setText(rpmCalibration.toString())
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        val interval = EditText(this).apply {
            hint = "Intervalo de leitura (ms)"
            setText(pollingIntervalMs.toString())
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        box.addView(label("Fator RPM Cal.")); box.addView(rpm)
        box.addView(label("Atualização do monitor (ms)")); box.addView(interval)
        AlertDialog.Builder(this)
            .setTitle("Ajustes")
            .setView(box)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Salvar") { _, _ ->
                rpmCalibration = rpm.text.toString().toDoubleOrNull()?.takeIf { it > 0 } ?: 1.0
                pollingIntervalMs = interval.text.toString().toLongOrNull()?.coerceIn(80, 2000) ?: 250L
                toast("Ajustes salvos")
            }.show()
    }

    private fun showProgramming() {
        val items = arrayOf("Programar Sonda / RPM", "Programar MAP", "Cancelar")
        AlertDialog.Builder(this)
            .setTitle("Programação TechRace")
            .setItems(items) { dialog, which ->
                when (which) {
                    0 -> confirmWrite(
                        "Programar Sonda / RPM",
                        "Inicia o aprendizado Sonda/RPM no módulo. Faça apenas com o motor nas condições corretas.",
                        TechRaceProtocol.PROGRAM_SONDA_RPM
                    )
                    1 -> confirmWrite(
                        "Programar MAP",
                        "Inicia o aprendizado do MAP. Mantenha as condições de calibração corretas e siga as orientações do módulo.",
                        TechRaceProtocol.PROGRAM_MAP
                    )
                    else -> dialog.dismiss()
                }
            }.show()
    }

    private fun showDiagnostics() {
        val rx = if (lastRx.isEmpty()) "--" else TechRaceProtocol.toHex(lastRx)
        val text = """
            Porta: ${if (port != null) "ABERTA" else "FECHADA"}
            Serial: 19200 8N1
            Polling: ${if (polling) "ATIVO" else "PARADO"}
            Erros: ${dashboard.errorCount}

            Último RX (${lastRx.size} bytes):
            $rx

            Comando leitura:
            ${TechRaceProtocol.toHex(TechRaceProtocol.READ_LIVE_10)}
        """.trimIndent()
        val tv = TextView(this).apply {
            setPadding(36, 22, 36, 22)
            setTextColor(Color.WHITE)
            setTextIsSelectable(true)
            textSize = 14f
            this.text = text
        }
        val scroll = ScrollView(this).apply { addView(tv) }
        AlertDialog.Builder(this).setTitle("Diagnóstico").setView(scroll).setPositiveButton("Fechar", null).show()
    }

    private fun showConfig() {
        val options = arrayOf(
            if (port == null) "Conectar USB OTG" else "Reconectar USB",
            if (polling) "Parar leitura contínua" else "Iniciar leitura contínua",
            "Ler uma vez",
            "Sobre a V2"
        )
        AlertDialog.Builder(this).setTitle("Configuração").setItems(options) { _, which ->
            when (which) {
                0 -> findAndConnect()
                1 -> togglePolling()
                2 -> pollOnce()
                3 -> AlertDialog.Builder(this)
                    .setTitle("TechRace Flex ECU V2")
                    .setMessage("Interface V2 com painel gráfico, monitor em tempo real, USB OTG, programação, diagnóstico e ajustes. A curva de temperatura ainda aguarda validação técnica.")
                    .setPositiveButton("OK", null).show()
            }
        }.show()
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; textSize = 14f; setPadding(0, 16, 0, 4)
    }

    private fun togglePolling() {
        if (port == null) { toast("Conecte o módulo primeiro"); return }
        polling = !polling
        dashboard.autoReading = polling
        if (polling) schedulePoll()
        toast(if (polling) "Leitura contínua iniciada" else "Leitura contínua parada")
    }

    private fun findAndConnect() {
        val drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)
        if (drivers.isEmpty()) {
            toast("Nenhum conversor USB-serial detectado")
            dashboard.connected = false
            return
        }
        val device = drivers.first().device
        if (!usbManager.hasPermission(device)) {
            val flags = PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            val permissionIntent = PendingIntent.getBroadcast(this, 0, Intent(actionUsbPermission).setPackage(packageName), flags)
            usbManager.requestPermission(device, permissionIntent)
            toast("Aguardando permissão USB...")
            return
        }
        openDevice(device)
    }

    private fun openDevice(device: UsbDevice) {
        ioExecutor.execute {
            try {
                try { port?.close() } catch (_: Exception) {}
                val driver = UsbSerialProber.getDefaultProber().probeDevice(device)
                    ?: throw IllegalStateException("Conversor USB-serial não reconhecido")
                val connection = usbManager.openDevice(device)
                    ?: throw IllegalStateException("Não foi possível abrir USB")
                val p = driver.ports.first()
                p.open(connection)
                p.setParameters(TechRaceProtocol.BAUD_RATE, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
                port = p
                mainHandler.post {
                    dashboard.connected = true
                    toast("Conectado @ 19200 8N1")
                    if (!polling) togglePolling()
                }
            } catch (e: Exception) {
                mainHandler.post {
                    dashboard.connected = false
                    dashboard.markCommunicationFailure()
                    toast("Erro USB: ${e.message}")
                }
            }
        }
    }

    private fun schedulePoll() {
        if (!polling) return
        pollOnce(onDone = { mainHandler.postDelayed({ schedulePoll() }, pollingIntervalMs) })
    }

    private fun pollOnce(onDone: (() -> Unit)? = null) {
        val p = port
        if (p == null) { onDone?.invoke(); return }
        ioExecutor.execute {
            try {
                p.write(TechRaceProtocol.READ_LIVE_10, 500)
                Thread.sleep(25)
                val buffer = ByteArray(128)
                val n = p.read(buffer, 250)
                val rx = if (n > 0) buffer.copyOf(n) else byteArrayOf()
                mainHandler.post { showResponse(rx) }
            } catch (e: Exception) {
                mainHandler.post {
                    dashboard.markCommunicationFailure()
                    toast("Falha de leitura: ${e.message}")
                }
            } finally { onDone?.invoke() }
        }
    }

    private fun showResponse(rx: ByteArray) {
        lastRx = rx
        val payload = TechRaceProtocol.extractLivePayload(rx)
        if (payload == null) {
            dashboard.markCommunicationFailure()
            return
        }
        try {
            dashboard.updateData(TechRaceDecoder.decode(payload, rpmCalibration))
        } catch (_: Exception) {
            dashboard.markCommunicationFailure()
        }
    }

    private fun confirmWrite(title: String, message: String, frame: ByteArray) {
        if (port == null) { toast("Conecte o módulo primeiro"); return }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage("$message\n\nTX: ${TechRaceProtocol.toHex(frame)}")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("ENVIAR") { _, _ -> sendFrame(frame) }
            .show()
    }

    private fun sendFrame(frame: ByteArray) {
        val p = port ?: return
        ioExecutor.execute {
            try {
                p.write(frame, 500)
                mainHandler.post { toast("Comando enviado") }
            } catch (e: Exception) {
                mainHandler.post {
                    dashboard.markCommunicationFailure()
                    toast("Falha ao enviar: ${e.message}")
                }
            }
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
