package br.com.anderson.techrace

data class TechRaceLiveData(
    val rpm: Double,
    val injectionMs: Double,
    val correctionPercent: Double,
    val raw4: Int,
    val raw6: Int,
    val temperatureRaw: Int,
    val mapVoltage: Double,
    val lambdaMv: Int
)

object TechRaceDecoder {
    fun decode(data: ByteArray, rpmCalibration: Double = 1.0): TechRaceLiveData {
        require(data.size >= 10) { "Payload deve ter pelo menos 10 bytes" }
        fun u(i: Int) = data[i].toInt() and 0xFF

        val rpmRaw = (u(1) shl 8) or u(0)
        val injectionRaw = (u(3) shl 8) or u(2)

        val rpm = if (rpmRaw == 0 || rpmCalibration == 0.0) 0.0
        else 60_000_000.0 / (rpmRaw * 3.2 * rpmCalibration)

        return TechRaceLiveData(
            rpm = rpm,
            injectionMs = injectionRaw * 0.0008,
            correctionPercent = u(5) * 100.0 / 64.0,
            raw4 = u(4),
            raw6 = u(6),
            temperatureRaw = u(7),
            mapVoltage = u(8) * 2.5 / 255.0,
            lambdaMv = u(9) * 5000 / 255
        )
    }
}
